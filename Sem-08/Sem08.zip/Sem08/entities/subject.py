class Subject:
    def __init__(self, name) -> None:
        self.name = name
        self.durability = 100
    def print(self):
        print(f"Subject {self.name}, {self.durability}")
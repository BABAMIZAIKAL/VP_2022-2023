from errors import CharacterTypeNotValid
class Character:
    TYPES = ("Warrior", "Mage", "Priest", "Rogue")
    def __init__(self, name, sex, klas) -> None:
        try:
            if klas not in Character.TYPES:
                raise CharacterTypeNotValid("Invalid character type")
            self.name = name
            self.sex = sex
            self.klas = klas
            self.weapon = None
            self.subject = None
        except CharacterTypeNotValid as e:
            print(e)
    def addWeapon(self, weapon):
        self.weapon = weapon
    def addSubject(self, subject):
        self.subject = subject
    def print(self):
        print(f"Character {self.name}, {self.sex}, {self.klas}, {self.weapon}, {self.subject}")
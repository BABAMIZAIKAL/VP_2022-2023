from .subject import Subject
from errors import InvalidAttack

class Weapon(Subject):
    def __init__(self, name, attack) -> None:
        super().__init__(name)
        try: 
            if type(attack) != int and attack < 0:
                raise InvalidAttack("Invalid attack")
            self.attack = attack
        except InvalidAttack as e:
            print(e)
    def print(self):
        print(f"Weapon {self.name}, {self.durability}, {self.attack}")
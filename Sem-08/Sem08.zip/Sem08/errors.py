
class InvalidCommand(Exception):
    pass
class InvalidDataFormat(Exception):
    pass
class CharacterExists(Exception):
    pass
class CharacterTypeNotValid(Exception):
    pass
class InvalidAttack(Exception):
    pass
class InvalidUserData(Exception):
    pass
class CharacterNotExist(Exception):
    pass
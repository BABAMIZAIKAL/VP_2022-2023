from entities import character, weapon, subject
from errors import InvalidCommand, InvalidDataFormat, CharacterExists, CharacterNotExist


class Menu:
    characters = []

    def print_menu():
        print("1. Create a new character")
        print("2. Create a new weapon")
        print("3. Create a new subject")
        print("4. Print all characters")
        print("5. Delete character")
    def print_all_charachters(self):
        for k in self.characters:
            k.print()
    def delete_character(self, char):
        self.characters.remove(char)
    def command_create_character(self, name, sex, ch_class) -> character.Character:
        a = character.Character(name=name, sex= sex, klas= ch_class)
        return a
    def find_character(name) -> character.Character:
        for i in Menu.characters:
            if i.name == name:
                return i
    def run(self):
        # infinite menu loop
        while True:  
            # print the menu
            # ...
            Menu.print_menu()

            # ask the user to choose a command
            choice = input("Choose an item from the menu: \n> ")

            # catch errors
            try:
                # process the user's choice
                if choice == "1":                    
                    # ask the user to input the necessary command parameters
                    name = input("Enter the character name (alpha-numeric): ")

                    if len(name) < 4 or not name.isalpha() :
                        raise InvalidDataFormat("Invalid names")
                    for i in Menu.characters:
                        if name == i.name:
                            raise CharacterExists("Character exists")
                    sex = input("Enter the character sex (alpha-numeric): ")
                    if len(sex) < 4 or not sex.isalpha():
                        raise InvalidDataFormat("Invalid sex")
                    klas = input("Enter the character klas (alpha-numeric): ")
                    if len(klas) < 4 or not klas.isalpha():
                        raise InvalidDataFormat("Invalid klas")

                    char = self.command_create_character(name= name, sex= sex, ch_class= klas)
                    Menu.characters.append(char)
                if choice == "2":
                    name = input("Enter the character name (alpha-numeric): ")
                    if len(name) < 4 or not name.isalpha() :
                        raise InvalidDataFormat("Invalid names")
                    a = 0
                    for i in Menu.characters:
                        if name == i.name:
                            a += 1
                    if a == 0:
                        raise CharacterNotExist("Character Not Exist")
                    char = Menu.find_character(name= name)
                    attack = input("Enter the weapon attack (numeric): ")
                    if not attack.isnumeric() or int(attack) < 0:
                        raise InvalidDataFormat("Invalid attack")
                    weaponName = input("Enter the weapon name (alpha-numeric): ")
                    if len(weaponName) < 4 or not weaponName.isalpha() :
                        raise InvalidDataFormat("Invalid weaponName")
                    char.addWeapon(weapon=weapon.Weapon(name= weaponName, attack= attack))
                if choice == "3":
                    name = input("Enter the character name (alpha-numeric): ")
                    if len(name) < 4 or not name.isalpha() :
                        raise InvalidDataFormat("Invalid names")
                    a = 0
                    for i in Menu.characters:
                        if name == i.name:
                            a += 1
                    if a == 0:
                        raise CharacterNotExist("Character Not Exist")
                    char = Menu.find_character(name= name)
                    subjectName = input("Enter the weapon name (alpha-numeric): ")
                    if len(subjectName) < 4 or not subjectName.isalpha() :
                        raise InvalidDataFormat("Invalid subjectName")
                    char.addSubject(subject=subject.Subject(name=subjectName))
                if choice == "4":
                    Menu.print_all_charachters()
                if choice == "5":
                    name = input("Enter the character name (alpha-numeric): ")
                    if len(name) < 4 or not name.isalpha() :
                        raise InvalidDataFormat("Invalid names")
                    char = Menu.find_character(name=name)
                    if char == None:
                        raise CharacterNotExist("Character Not Exist")
                else:
                    raise InvalidCommand("Error: Invalid choice")
            except ValueError:
                print("Character for delete not found")
            except InvalidDataFormat as e:
                print(e)
            except CharacterExists as e:
                print(e)
            except CharacterNotExist as e:
                print(e)
            except Exception as ex:
                print(f"Error: {str(ex)}")
            
            print()

if __name__ == '__main__':
    menu = Menu()
    menu.run()